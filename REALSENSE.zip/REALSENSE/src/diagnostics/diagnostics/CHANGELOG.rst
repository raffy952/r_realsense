^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package diagnostics
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

3.1.2 (2023-03-24)
------------------

3.1.1 (2023-03-16)
------------------
* Maintainer update
* Contributors: Austin, Ralph Lange

3.1.0 (2023-01-26)
------------------
* Adding READMEs to the repo (`#270 <https://github.com/ros/diagnostics/issues/270>`_)
* License fixes (`#263 <https://github.com/ros/diagnostics/issues/263>`_)
* Fix/cleanup ros1 (`#257 <https://github.com/ros/diagnostics/issues/257>`_)
* Contributors: Austin, Christian Henkel, Ralph Lange

1.9.3 (2018-05-02)
------------------

1.9.2 (2017-07-15)
------------------

1.9.1 (2017-07-15)
------------------

1.9.0 (2017-04-25)
------------------

1.8.10 (2016-06-14)
-------------------

1.8.9 (2016-03-02)
------------------

1.8.8 (2015-08-06)
------------------

1.8.7 (2015-01-09)
------------------

1.8.6 (2014-12-10)
------------------

1.8.5 (2014-07-29)
------------------

1.8.4 (2014-07-24 20:51)
------------------------

1.8.3 (2014-04-23)
------------------

1.8.2 (2014-04-08)
------------------

1.8.1 (2014-04-07)
------------------
* Add myself as maintainer
* Contributors: Austin Hendrix

1.8.0 (2013-04-03)
------------------
* Updating metapackages to reflect REP-0127
* Contributors: William Woodall

1.7.11 (2014-07-24 20:24)
-------------------------
* Restore diagnostics meta package description
  For the wiki etc.
* Updating metapackages to reflect REP-0127
* Contributors: Felix Kolbe, William Woodall

1.7.10 (2013-02-22)
-------------------
* Changed package.xml version number before releasing
* Contributors: Brice Rebsamen

1.7.9 (2012-12-14)
------------------

1.7.8 (2012-12-06)
------------------

1.7.7 (2012-11-10)
------------------

1.7.6 (2012-11-07 23:32)
------------------------

1.7.5 (2012-11-07 21:53)
------------------------

1.7.4 (2012-11-07 20:18)
------------------------

1.7.3 (2012-11-04)
------------------

1.7.2 (2012-10-30 22:31)
------------------------

1.7.1 (2012-10-30 15:30)
------------------------
* fix a few things after the first release
* add the meta-package
* Contributors: Vincent Rabaud

1.7.0 (2012-10-29)
------------------
